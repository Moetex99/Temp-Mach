﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FightingGameOOP
{
    class Arena
    {
        public bool Battle(Fighter fighter1, Fighter fighter2)
        {
            bool winner;
            string move1;
            string move2;

            bool firstMove;
            int round = 1;
            string f1name = fighter1.Name;
            string f2name = fighter2.Name;

            Console.WriteLine($"A battle has begun between {fighter1.Name} and {fighter2.Name} \n");
            Thread.Sleep(1000);

            while (fighter1.Health > 0 && fighter2.Health > 0)
            {
                move1 = "null";
                move2 = "null";

                Console.WriteLine($"Get ready for turn {round} \n");
                Thread.Sleep(500);

                Console.WriteLine($"[{fighter1.Name}] has {fighter1.Health} health; and [{fighter2.Name}] has {fighter2.Health} health \n");

                firstMove = CoinFlip.CalcTurn(fighter1, fighter2);

                if (firstMove == true)
                {
                    Console.WriteLine($"{fighter1.Name} was quicker, they act first \n");
                    Hero.HeroTurn(fighter1, fighter2);

                    Console.WriteLine($"{fighter2.Name} is now ready to act \n");
                    Villain.VillainTurn(fighter2, fighter1);
                }

                if (firstMove == false)
                {
                    Console.WriteLine($"{fighter2.Name} was quicker, they act first \n");
                    Villain.VillainTurn(fighter2, fighter1);

                    Console.WriteLine($"{fighter1.Name} is now ready to act \n");
                    Hero.HeroTurn(fighter1, fighter2);
                }

                round = round + 1;
            }

            if (fighter1.Health <= 0)
            {
                winner = false;
            }
            else
            {
                winner = true;
            }

            return winner;
        }
    }
}
