﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FightingGameOOP
{
    class Program
    {
        static Fighter fighter1;
        static Fighter fighter2;
        static Random rnd = new Random();
        static Arena arena = new Arena();

        static void Main(string[] args)
        {
            Console.WriteLine("*** A battle has begun! \n");

            GenerateFighters();

            Console.WriteLine($"The battle will take place between [{fighter1.Name}] and [{fighter2.Name}] \n\n");
            Thread.Sleep(2000);

            Console.WriteLine("The combatants head to the arena \n");
            Thread.Sleep(1000);

            bool winner = arena.Battle(fighter1, fighter2);

            if (winner == true)
            {
                Console.WriteLine($"Congrats! [{fighter1.Name}] has won!");
                Console.ReadKey();
            }
            else if (winner == false)
            {
                Console.WriteLine($" Better luck next time [{fighter1.Name}], [{fighter2.Name}] has won");
                Console.ReadKey();
            }
        }

        static void GenerateFighters()
        {
            fighter1 = new Fighter("Player");

            string f2name;

            int prob = rnd.Next(1, 101);

            if (prob > 0 && prob <= 5)
            {
                f2name = "Bagool";
            }
            else if (prob > 5 && prob <= 20)
            {
                f2name = "Enemy2";
            }
            else
            {
                f2name = "Enemy1";
            }

            fighter2 = new Fighter(f2name);
        }
    }
}
