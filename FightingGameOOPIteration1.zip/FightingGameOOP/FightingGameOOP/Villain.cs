﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FightingGameOOP
{
    class Villain
    {
        static bool brace1;
        static bool brace2;
        static bool charge1;
        static bool charge2;
        static Random rnd = new Random();

        public static void VillainTurn(Fighter f1, Fighter f2)
        {
            int villainAtk;
            int heroDef;
            string move = "null";
            int result = 0;
            int damage = 0;

            int chance = rnd.Next(1, 101);
            if (chance > 0 && chance <= 20)
            {
                move = "charge";
            }
            else if ( chance > 20 && chance <= 50)
            {
                move = "brace";
            }
            else
            {
                move = "attack";
            }

            if (move == "attack")
            {
                Console.WriteLine($"[{f2.Name}] attacks! \n");
                Thread.Sleep(500);

                villainAtk = rnd.Next(1, 11) + f2.Atk;

                if (charge2 == true)
                {
                    villainAtk = villainAtk + villainAtk / 4;
                }

                heroDef = rnd.Next(1, 9) + f1.Def;

                if (brace1 == true)
                {
                    heroDef = heroDef + heroDef / 2;
                }
                else if (charge1 == true)
                {
                    heroDef = heroDef / 2;
                }

                result = villainAtk - heroDef;

                if (result > -5 && result <=0)
                {
                    Console.WriteLine($"[{f1.Name}] deflects [{f2.Name}'s] attack \n");
                    Thread.Sleep(500);
                }
                else if (result < -5)
                {
                    Console.WriteLine($"[{f1.Name}] counters! \n ");
                    Thread.Sleep(500);
                    damage = rnd.Next(f1.Counter[0], f1.Counter[1] + 1);
                    Console.WriteLine($"[{f2.Name}] takes [{damage}] damage \n");
                    Thread.Sleep(500);
                    f2.Damage(damage);
                }
                else if (result > 0)
                {
                    Console.WriteLine($"[{f2.Name}] lands a hit! \n");
                    Thread.Sleep(500);
                    damage = rnd.Next(f2.Dam[0], f2.Dam[1] + 1);
                    if (charge1 == true)
                    {
                        damage = damage + damage / 2;
                    }
                    Console.WriteLine($"[{f1.Name}] takes [{damage}] damage \n");
                    Thread.Sleep(500);
                    f1.Damage(damage);
                }

                charge2 = false;
                brace2 = false;
                brace1 = false;
            
            }

            else if ( move == "brace")
            {
                Console.WriteLine($"[{f2.Name}] braces for defense \n");
                Thread.Sleep(800);
                brace2 = true;
                charge2 = false;
            }
            else if (move == "charge")
            {
                Console.WriteLine($"[{f2.Name}] prepares their strength for the next attack \n");
                Thread.Sleep(800);
                charge2 = true;
                brace2 = false;
            }
        }
    }
}
