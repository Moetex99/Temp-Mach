﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingGameOOP
{
    class CoinFlip
    {
        static Random rnd = new Random();

        public static bool CalcTurn(Fighter f1, Fighter f2)
        {
            int heroSpeed;
            int villianSpeed;

            heroSpeed = rnd.Next(1, 11) + f1.Speed;
            villianSpeed = rnd.Next(1, 11) + f2.Speed;

            if (heroSpeed > villianSpeed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
