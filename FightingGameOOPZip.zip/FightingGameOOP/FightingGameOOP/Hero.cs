﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FightingGameOOP
{
    class Hero
    {
        static bool brace1;
        static bool brace2;
        static bool charge1;
        static bool charge2;
        static Random rnd = new Random();

        public static void HeroTurn(Fighter f1, Fighter f2)
        {
            int heroAtk;
            int villianDef;
            string move = null;
            int result = 0;
            int damage = 0;

            while (move != "attack" && move != "brace" && move != "charge")
            {
                Console.WriteLine("Select [attack], [brace], or [charge] \n");
                move = Console.ReadLine();

                if (move == "attack") 
                {
                    Console.WriteLine($"[{f1.Name}] attacks \n");
                    Thread.Sleep(500);

                    heroAtk = rnd.Next(1, 11) + f1.Atk;

                    if (charge1 == true)
                    {
                        heroAtk = heroAtk + heroAtk / 4;
                    }

                    villianDef = rnd.Next(1, 9) + f2.Def;

                    if (brace2 == true)
                    {
                        villianDef = villianDef + villianDef / 2;
                    }

                    else if (charge2 == true)
                    {
                        villianDef = villianDef / 2;
                    }

                    result = heroAtk - villianDef;

                    if (result > -5 && result <= 0)
                    {
                        Console.WriteLine($"[{f2.Name}] deflects [{f1.Name}'s] attack \n");
                        Thread.Sleep(500);
                    }
                    else if (result < -5)
                    {
                        Console.WriteLine($"[{f2.Name}] counters \n");
                        Thread.Sleep(500);

                        damage = rnd.Next(f2.Counter[0], f2.Counter[1] + 1);

                        Console.WriteLine($"[{f1.Name}] takes [{damage}] damage \n");
                        Thread.Sleep(500);

                        f1.Damage(damage);
                    }
                    else if (result > 0)
                    {
                        Console.WriteLine($"[{f1.Name}] lands a hit! \n");
                        Thread.Sleep(500);

                        damage = rnd.Next(f1.Dam[0], f1.Dam[1] + 1);

                        if (charge1 == true)
                        {
                            damage = damage + damage / 2;
                        }

                        Console.WriteLine($"[{f2.Name}] takes [{damage}] damage \n");
                        Thread.Sleep(500);

                        f2.Damage(damage);
                    }

                    charge1 = false;
                    brace1 = false;
                    brace2 = false;
                }
                else if (move == "brace")
                {
                    Console.WriteLine($"[{f1.Name}] braces for defense \n");
                    Thread.Sleep(800);

                    brace1 = true;
                    charge1 = false;
                }
                else if (move == "charge")
                {
                    Console.WriteLine($"[{f1.Name}] prepares their strength for the next attack \n");
                    Thread.Sleep(800);

                    charge1 = true;
                    brace1 = false;
                }
            }

        }
    }
}
