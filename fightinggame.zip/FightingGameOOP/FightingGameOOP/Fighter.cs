﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FightingGameOOP
{
    class Fighter
    {
        private string name;
        private int health;
        private int atk;
        private int def;
        private int speed;
        private int[] dam = new int[2];
        private int[] counter = new int[2];

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        
        public int Atk
        {
            get { return atk; }
            set { atk = value; }
        }

        public int Def
        {
            get { return def; }
            set { def = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public int[] Dam
        {
            get { return dam; }
            set { dam = value; }
        }

        public int[] Counter
        {
            get { return counter; }
            set { counter = value; }
        }

        public Fighter(string fname)
        {
            if (fname == "Player")
            {
                Name = "Player";
                Atk = 5;
                Def = 5;
                Speed = 10;
                Health = 10;
                Dam[0] = 1;
                Dam[1] = 4;
                Counter[0] = 3;
                Counter[1] = 5;
            }

            else if (fname == "Enemy1")
            {
                Name = "Enemy1";
                Atk = 7;
                Def = 3;
                Speed = 5;
                Health = 10;
                Dam[0] = 1;
                Dam[1] = 5;
                Counter[0] = 1;
                Counter[1] = 2;
            }

            else if (fname == "Enemy2")
            {
                Name = "Enemy2";
                Atk = 9;
                Def = 6;
                Speed = 7;
                Health = 12;
                Dam[0] = 2;
                Dam[1] = 6;
                Counter[0] = 1;
                Counter[1] = 6;
            }
            else if (fname == "Bagool")
            {
                Name = "Bagool";
                Atk = 0;
                Def = 0;
                Speed = 0;
                Health = 1;
                Dam[0] = 0;
                Dam[1] = 1;
                Counter[0] = 0;
                Counter[1] = 1;
            }
        }
        
        public void Damage(int damage)
        {
            this.health = this.health - damage;
        }
    }
}
